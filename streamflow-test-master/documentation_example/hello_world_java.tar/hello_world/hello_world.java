// Hello_World.java
public class Hello_World {

    public static void main(String[] args) {
        // Print "Hello, World!" naar de console
        System.out.println("Hello, World!");
    }
}